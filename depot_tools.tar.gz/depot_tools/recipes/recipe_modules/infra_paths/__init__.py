DEPS = [
  'recipe_engine/path',
  'recipe_engine/properties',
]
